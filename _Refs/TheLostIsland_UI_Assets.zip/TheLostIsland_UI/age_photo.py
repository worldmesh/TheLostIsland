#!/usr/bin/env python3
"""
age_photo.py — превращает рендер из Unreal в состаренное фото для дневника.

Зачем скриптом, а не руками в фотошопе: все фото в дневнике получат ОДИНАКОВУЮ
обработку. Именно одинаковость и читается как «дизайн», а не «набрано из разного».

Использование:
    python age_photo.py render.png                    # один файл
    python age_photo.py renders/*.png -o out/         # пачкой
    python age_photo.py render.png --style sketch     # карандашная зарисовка

Стили:
    photo   (по умолчанию) — выцветшее фото: сепия, зерно, рваный край
    sketch                 — карандашный набросок на бумаге

Крутилки — в блоке PRESETS ниже. Правь и прогоняй заново, пока не понравится.

Зависимости:  pip install pillow numpy scipy
"""

import argparse, glob, os, sys
import numpy as np
from PIL import Image, ImageFilter

# --------------------------------------------------------------------------
PRESETS = {
    "photo": dict(
        desaturate   = 0.82,   # 0 = цвет как есть, 1 = полностью ч/б
        sepia        = 0.55,   # сила тонирования в сепию
        lift_shadows = 0.13,   # поднять тени (выцветшая печать не бывает чёрной)
        contrast     = 0.88,   # <1 — мягче
        grain        = 0.038,  # зерно плёнки
        vignette     = 0.42,   # затемнение углов
        blur         = 0.6,    # лёгкая нерезкость старого отпечатка
        paper_mix    = 0.22,   # сколько бумаги проступает сквозь фото
        edge_ragged  = 0.55,   # рваность края (0 — ровный прямоугольник)
        border_px    = 14,     # светлое поле фотографии по краю
    ),
    "sketch": dict(
        desaturate=1.0, sepia=0.42, lift_shadows=0.0, contrast=1.15,
        grain=0.025, vignette=0.18, blur=0.0, paper_mix=0.55,
        edge_ragged=0.35, border_px=0,
        pencil_radius=6.0,   # толщина штриха
        pencil_darkness=1.5, # 1.0 — бледно, 2.0 — жирно
    ),
}
SEPIA_TINT = np.array([1.07, 0.98, 0.80])     # тёплый сдвиг
PAPER_RGB  = np.array([214, 199, 172], float)  # тон бумаги дневника
# --------------------------------------------------------------------------


def _band(shape, f0, sigma_rel=0.75, seed=0):
    """Полосовой шум — бесшовный по построению, используется для зерна и краёв."""
    h, w = shape
    n = max(h, w)
    rng = np.random.default_rng(seed)
    W = np.fft.fft2(rng.standard_normal((n, n)))
    fy = np.fft.fftfreq(n)[:, None]
    fx = np.fft.fftfreq(n)[None, :]
    r = np.hypot(fx, fy)
    L = np.real(np.fft.ifft2(W * np.exp(-((r - f0) ** 2) / (2 * (f0 * sigma_rel + 1e-9) ** 2))))
    L = L / (L.std() or 1.0)
    return L[:h, :w]


def _ragged_mask(h, w, strength, border_px):
    """Альфа с неровным, слегка обтрёпанным краем."""
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.minimum.reduce([xx, yy, w - 1 - xx, h - 1 - yy])
    base = float(border_px) + 2.0
    if strength > 0:
        wobble = (_band((h, w), 6.0 / max(h, w), 0.8, seed=5) * 0.6
                  + _band((h, w), 26.0 / max(h, w), 0.8, seed=6) * 0.4)
        base = base + wobble * (min(h, w) * 0.035 * strength)
    return np.clip(d - base, 0.0, 2.0) / 2.0


def age(img: Image.Image, style="photo", **over) -> Image.Image:
    p = dict(PRESETS[style]); p.update({k: v for k, v in over.items() if v is not None})
    im = img.convert("RGB")
    if p["blur"] > 0:
        im = im.filter(ImageFilter.GaussianBlur(p["blur"]))
    a = np.asarray(im).astype(np.float32) / 255.0
    h, w = a.shape[:2]

    if style == "sketch":
        # Классический «карандаш»: инвертируем, размываем, смешиваем режимом Color Dodge.
        g = a @ np.array([0.299, 0.587, 0.114])
        inv = Image.fromarray(((1.0 - g) * 255).astype(np.uint8))
        inv = np.asarray(inv.filter(ImageFilter.GaussianBlur(p["pencil_radius"]))).astype(np.float32) / 255.0
        dodge = np.clip(g / np.maximum(1.0 - inv, 1e-3), 0, 1)
        g = np.clip(1.0 - (1.0 - dodge) * p["pencil_darkness"], 0, 1)
        a = np.dstack([g, g, g])
    else:
        lum = a @ np.array([0.299, 0.587, 0.114])
        a = a * (1 - p["desaturate"]) + lum[..., None] * p["desaturate"]

    a = np.clip(a * (SEPIA_TINT * p["sepia"] + (1 - p["sepia"])), 0, 1)
    a = a * (1 - p["lift_shadows"]) + p["lift_shadows"]
    a = np.clip((a - 0.5) * p["contrast"] + 0.5, 0, 1)

    if p["paper_mix"] > 0:
        paper = PAPER_RGB / 255.0 * (1 + _band((h, w), 3.0 / max(h, w), 0.9, seed=9)[..., None] * 0.06)
        a = a * (1 - p["paper_mix"]) + a * paper * p["paper_mix"] * 2.0
        a = np.clip(a, 0, 1)

    if p["grain"] > 0:
        a = np.clip(a + _band((h, w), 0.34, 0.9, seed=12)[..., None] * p["grain"], 0, 1)

    if p["vignette"] > 0:
        yy, xx = np.mgrid[0:h, 0:w]
        r = np.hypot((xx / (w - 1) - .5) * 2, (yy / (h - 1) - .5) * 2) / 1.4142
        a *= (1 - np.clip((r - .45) / .55, 0, 1)[..., None] ** 1.6 * p["vignette"])

    if p["border_px"] > 0:
        m = _ragged_mask(h, w, 0, p["border_px"] - 4)
        a = a * m[..., None] + (PAPER_RGB / 255.0 * 1.06)[None, None, :] * (1 - m[..., None])

    alpha = _ragged_mask(h, w, p["edge_ragged"], 0)
    rgba = np.dstack([np.clip(a, 0, 1) * 255, alpha * 255]).astype(np.uint8)
    return Image.fromarray(rgba, "RGBA")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+")
    ap.add_argument("-o", "--outdir", default="aged")
    ap.add_argument("--style", default="photo", choices=list(PRESETS))
    ap.add_argument("--max", type=int, default=1024, help="макс. сторона результата")
    for k in ("sepia", "grain", "vignette", "paper_mix", "edge_ragged", "contrast"):
        ap.add_argument(f"--{k}", type=float, default=None)
    args = ap.parse_args()

    files = [f for pat in args.inputs for f in glob.glob(pat)]
    if not files:
        sys.exit("Файлы не найдены")
    os.makedirs(args.outdir, exist_ok=True)
    over = {k: getattr(args, k) for k in ("sepia", "grain", "vignette", "paper_mix", "edge_ragged", "contrast")}

    for f in files:
        im = Image.open(f)
        im.thumbnail((args.max, args.max), Image.LANCZOS)
        out = age(im, args.style, **over)
        dst = os.path.join(args.outdir, f"T_Photo_{os.path.splitext(os.path.basename(f))[0]}.png")
        out.save(dst)
        print(f"{os.path.basename(f)}  ->  {dst}  {out.size}")


if __name__ == "__main__":
    main()
